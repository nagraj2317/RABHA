# RabhAI — floating assistant for the real home screen

This is a small Android app. It draws the six-cell panel **over your actual home screen**
(wallpaper, icons and swipeable pages stay visible behind it), takes voice commands, and
removes itself when the assistant is done. The app stays installed.

The whole interface is the HTML file in `app/src/main/assets/index.html`, loaded in a
transparent WebView. You can change the interface without touching the Kotlin code.

---

## Build it (one time, about 5 minutes)

You need a computer — Windows, Mac or Linux.

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → **Open** → choose the `rabhai-android` folder.
   If it asks to create the Gradle wrapper, say **Yes** and wait for the sync to finish.
3. Plug your phone in with USB, and on the phone turn on
   **Settings → About phone → tap Build number 7 times**, then
   **Developer options → USB debugging**.
4. In Android Studio press **Run ▶**. The app installs on your phone.

To get a file you can send to someone: **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
The APK lands in `app/build/outputs/apk/debug/`.

No computer? You can build the same folder in the cloud with **Codemagic** or a
**GitHub Actions** workflow, or use an online “build Android project” service — all of
them accept this exact folder.

---

## Set it up on the phone (once)

Open **RabhAI** from the app drawer:

1. **Allow display over other apps** — the phone opens a settings screen, switch RabhAI on.
2. **Allow microphone** — needed for the voice ring.
3. **Show RabhAI on my home screen**.

From then on the panel floats over your launcher. Your wallpaper and the pages behind it
stay visible through the glass.

---

## How it behaves

- The overlay is **not focusable at first**, so your home screen still scrolls around the panel.
  Tap the command bar and it takes the keyboard; close the keyboard and it lets go.
- The voice ring uses the phone's own speech recogniser (English-India by default — change
  `EXTRA_LANGUAGE` in `OverlayService.kt` for Gujarati, `gu-IN`).
- When the assistant finishes, or after **30 seconds** with no use, the overlay removes itself
  from the home screen. The app stays installed — open it again from the drawer.
- The notification has a **Hide overlay** button and tells you it is running.

## What a web page could not do, and this can

| Thing | Web page | This app |
|---|---|---|
| Draw over the real home screen | no | yes (`SYSTEM_ALERT_WINDOW`) |
| Stay above other apps | no | yes (foreground service) |
| Use the phone's speech engine | no | yes (`SpeechRecognizer`) |
| Keep running with the screen on | no | yes |

## What still needs more work

- **Always-on wake word** (“RabhAI” without tapping) needs a dedicated wake-word engine
  (Porcupine, Vosk, or Android’s `AlwaysOnHotwordDetector`). Right now you tap the ring.
- **Reading your screen** (the “collect these tools from this video” feature) needs an
  Accessibility Service — the manifest hook is not included yet.
- **Driving YouTube / Instagram** needs Accessibility actions too; the web version only opens
  a search page.
- Files, folders, contacts and memory live in the WebView’s local storage on the phone.

## Files

```
rabhai-android/
├── app/src/main/assets/index.html      ← the whole interface
├── app/src/main/java/ai/rabhai/overlay/
│   ├── MainActivity.kt                 ← the three setup buttons
│   └── OverlayService.kt               ← floating window + speech bridge
├── app/src/main/AndroidManifest.xml    ← the three permissions
└── app/build.gradle.kts
```

---

## Update the interface from the phone (no rebuild)

Open the app → **Admin → Design → Interface file**:

- **Download current** saves the running interface as `rabhai-interface.html`.
- Edit that file on your phone or computer — add your features, write in the file where they go.
- **Upload** it back. The app stores the file and runs **your** file instead of the built-in one.
  A small *RabhAI · built-in* pill in the corner switches back if the uploaded file breaks.

The same works in the browser version. Your uploaded file lives in the app's storage, so the
Android project never has to be rebuilt or reinstalled to change the interface.

---

## Get an APK without a computer

The folder already contains a build workflow (`.github/workflows/build-apk.yml`).

1. Create a free GitHub account and a new **empty** repository called `rabhai`.
2. Upload the contents of this folder to it (GitHub → *Add file → Upload files*, drag everything).
3. Open the **Actions** tab → *Build RabhAI APK* → **Run workflow**.
4. Wait about four minutes. Open the finished run → **Artifacts** → download `rabhai-apk`.
5. Unzip it on your phone, tap the `.apk`, allow *install unknown apps*, install.

That gives you a real installable APK with no computer and no Android Studio.
