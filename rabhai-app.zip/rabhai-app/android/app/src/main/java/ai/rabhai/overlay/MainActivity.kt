package ai.rabhai.overlay

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        askMic()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(40), dp(22), dp(30))
            setBackgroundColor(Color.parseColor("#050506"))
        }

        root.addView(TextView(this).apply {
            text = "RabhAI"
            setTextColor(Color.parseColor("#ffd79a"))
            textSize = 30f
            letterSpacing = 0.04f
        })

        root.addView(TextView(this).apply {
            text = "Floating assistant for your home screen"
            setTextColor(Color.parseColor("#8d8a83"))
            textSize = 13f
            setPadding(0, dp(6), 0, dp(26))
        })

        status = TextView(this).apply {
            setTextColor(Color.parseColor("#c9c5bc"))
            textSize = 13f
            setPadding(0, 0, 0, dp(20))
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        root.addView(status)

        root.addView(button("1 · Allow display over other apps") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        })

        root.addView(button("2 · Allow microphone") { askMic() })

        root.addView(button("3 · Show RabhAI on my home screen", primary = true) {
            if (!Settings.canDrawOverlays(this)) {
                toastBlocked()
                return@button
            }
            ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java)
            )
            finish()
        })

        root.addView(button("Hide the overlay") {
            startService(
                Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_HIDE)
            )
        })

        root.addView(TextView(this).apply {
            text = "The overlay sits above your launcher. The page is transparent, so your wallpaper " +
                "and icons stay visible behind the six cells. It removes itself when the assistant " +
                "finishes, or after 30 seconds of no use — the app stays installed."
            setTextColor(Color.parseColor("#6f6c66"))
            textSize = 12f
            setPadding(0, dp(24), 0, 0)
            setLineSpacing(dp(4).toFloat(), 1f)
        })

        return ScrollView(this).apply { addView(root) }
    }

    private fun button(label: String, primary: Boolean = false, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(if (primary) Color.parseColor("#1a1206") else Color.parseColor("#f5b942"))
            setBackgroundColor(
                if (primary) Color.parseColor("#f5b942") else Color.parseColor("#141312")
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { setMargins(0, 0, 0, dp(10)) }
            setOnClickListener { onClick() }
        }

    private fun askMic() {
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 7
            )
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        status.text = buildString {
            append(if (overlay) "✓ Display over other apps" else "• Display over other apps — not granted")
            append("\n")
            append(if (mic) "✓ Microphone" else "• Microphone — not granted")
        }
    }

    private fun toastBlocked() {
        status.text = "Grant “display over other apps” first, then come back."
    }
}
