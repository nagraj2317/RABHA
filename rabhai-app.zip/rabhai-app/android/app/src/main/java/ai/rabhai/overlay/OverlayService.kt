package ai.rabhai.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONObject

/**
 * Draws RabhAI over the real home screen.
 * The page is transparent, so your wallpaper and icons stay visible behind the six cells.
 * When the assistant finishes (or after the idle timeout) the overlay removes itself and
 * the app stays installed.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var web: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var recognizer: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE) {
            hideOverlay()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val ch = "rabhai_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(ch) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(ch, "RabhAI overlay", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val hide = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_HIDE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, ch) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("RabhAI is on your home screen")
            .setContentText("Tap the notification to open settings")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Hide overlay", hide).build())
            .setOngoing(true)
            .build()
    }

    private fun showOverlay() {
        val view = WebView(this)
        view.setBackgroundColor(Color.TRANSPARENT)
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)   // microphone for the voice ring
            }
        }
        view.addJavascriptInterface(Bridge(), "RabhAI")
        view.loadUrl("file:///android_asset/index.html?overlay=1")
        web = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        // not focusable at first, so your home screen still scrolls around the panel
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        lp = params
        wm.addView(view, params)
    }

    /** the page asks for this when you tap the command bar */
    private fun setFocusable(on: Boolean) {
        val view = web ?: return
        val params = lp ?: return
        params.flags = if (on)
            params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else
            params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(view, params) } catch (e: Exception) { }
    }

    private fun hideOverlay() {
        web?.let {
            it.loadUrl("about:blank")
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        web = null
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "No speech service on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: Bundle?) {
                        val text = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull().orEmpty()
                        js("window.onNativeSpeech && window.onNativeSpeech(${JSONObject.quote(text)})")
                    }
                    override fun onError(error: Int) {
                        js("window.onNativeSpeechError && window.onNativeSpeechError($error)")
                    }
                    override fun onRmsChanged(rmsdB: Float) {
                        js("window.onNativeLevel && window.onNativeLevel(${rmsdB.toDouble()})")
                    }
                    override fun onReadyForSpeech(params: Bundle?) { }
                    override fun onBeginningOfSpeech() { }
                    override fun onBufferReceived(buffer: ByteArray?) { }
                    override fun onEndOfSpeech() { }
                    override fun onPartialResults(partialResults: Bundle?) { }
                    override fun onEvent(eventType: Int, params: Bundle?) { }
                })
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { }
    }

    private fun js(code: String) {
        web?.post { web?.evaluateJavascript(code, null) }
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun finish() {
            stopSelf()
        }

        @JavascriptInterface
        fun openApp() {
            startActivity(
                Intent(this@OverlayService, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        @JavascriptInterface
        fun startListening() {
            listen()
        }

        @JavascriptInterface
        fun requestFocus() {
            setFocusable(true)
        }

        @JavascriptInterface
        fun releaseFocus() {
            setFocusable(false)
        }

        @JavascriptInterface
        fun listApps(): String {
            val out = org.json.JSONArray()
            val pm = packageManager
            val seen = HashSet<String>()
            for (ai in pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)) {
                if (!pm.getLaunchIntentForPackage(ai.packageName).let { it != null }) continue
                val name = pm.getApplicationLabel(ai).toString()
                if (!seen.add(name)) continue
                val cat = when {
                    ai.packageName.contains("chat") || name.contains("WhatsApp", true) ||
                        name.contains("Telegram", true) || name.contains("Instagram", true) -> "chat"
                    ai.packageName.contains("youtube") || ai.packageName.contains("netflix") ||
                        ai.packageName.contains("spotify") -> "entertainment"
                    ai.packageName.contains("openai") || ai.packageName.contains("gemini") ||
                        ai.packageName.contains("bard") -> "ai"
                    else -> "other"
                }
                out.put(org.json.JSONObject().put("name", name).put("pkg", ai.packageName).put("cat", cat))
            }
            return out.toString()
        }

        @JavascriptInterface
        fun openAppByName(name: String, query: String) {
            val pm = packageManager
            for (ai in pm.getInstalledApplications(0)) {
                val label = pm.getApplicationLabel(ai).toString()
                if (label.equals(name, true) || label.contains(name, true)) {
                    val i = pm.getLaunchIntentForPackage(ai.packageName)
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        if (query.isNotBlank()) i.putExtra(Intent.EXTRA_TEXT, query)
                        startActivity(i)
                        return
                    }
                }
            }
            Toast.makeText(this@OverlayService, "No app called $name", Toast.LENGTH_SHORT).show()
        }

    }

    companion object {
        const val NOTIF_ID = 41
        const val ACTION_HIDE = "ai.rabhai.overlay.HIDE"
    }
}
