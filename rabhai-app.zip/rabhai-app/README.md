# RabhAI — home panel

`index.html` is the whole app: one file, no server, no internet needed.

## What is inside the file

**Panel**
- Your own artwork, untouched in style, with the old partition lines removed
- One gallery / corridor linking all four rooms
- 7 doors that open only while someone is walking near them
- 20 desks with a glowing screen on every one
- 20 staff, one per desk — always seated, never disappearing
- 4 travellers: fade in beside their desk, walk the corridor, stand about
  3 seconds at a colleague's desk, walk back, fade out at their own desk
- Live log in green / red / blue
- Listening ring in four colours, each moving differently
- Typing hands, blinking caret, pulsing centre, flickering screens

**Controls**
- `⛶ Full screen` — fullscreen + landscape lock
- `W − 176% +` and `H − 128% +` — separate width and height scale, remembered

**Not in this build (on purpose)**
- The character is paused. It will come back through the upgrade system,
  by dropping an HTML file in and refreshing.

## Build the APK with GitHub (no PC needed)

1. Create a new **public** repository on github.com, e.g. `rabhai`.
2. Upload the **contents of the `android` folder** (not the folder itself) so
   that `.github/workflows/build-apk.yml` sits at the repository root.
3. Open the **Actions** tab. The workflow `Build APK` runs on its own.
4. Wait 3–5 minutes, open the finished run, and download the artifact
   `rabhai-apk` — that zip contains `app-debug.apk`.
5. Copy the APK to the phone, tap it, allow "Install unknown apps", install.
6. Open RabhAI → grant "Display over other apps" and the accessibility
   permission → the panel floats over your home screen.

To update the app later: replace `android/app/src/main/assets/index.html`
with the new file, commit, and the workflow builds a fresh APK.
